"""
setup_sheets.py - Google Sheets'ga yangi 4 ta filial uchun Zakaz va alohida Tranzaksiya varaqlarini avtomatik qo'shish va Остатки_Live'ni yangilash.
"""

import gspread
from google.oauth2.service_account import Credentials
import os
import json
import config

def main():
    scopes = ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive"]
    creds = None
    
    secret_path = "/etc/secrets/credentials.json"
    if os.path.exists(secret_path):
        creds = Credentials.from_service_account_file(secret_path, scopes=scopes)
    elif os.getenv("GOOGLE_CREDENTIALS_JSON"):
        creds_info = json.loads(os.getenv("GOOGLE_CREDENTIALS_JSON"))
        creds = Credentials.from_service_account_info(creds_info, scopes=scopes)
    elif os.path.exists(config.SERVICE_ACCOUNT_PATH):
        creds = Credentials.from_service_account_file(config.SERVICE_ACCOUNT_PATH, scopes=scopes)
    else:
        print("❌ Xatolik: Google credentials ma'lumotlari topilmadi!")
        return

    client = gspread.authorize(creds)
    sh = client.open_by_key(config.GOOGLE_SHEET_KEY)
    
    existing_sheets = [w.title for w in sh.worksheets()]
    new_branches = ["Чилонзор", "Бунёдкор", "Шевченко", "Саракулка"]
    
    for b in new_branches:
        # 1. Zakaz varag'ini yaratish
        order_sheet_name = f"Заказ_{b}"
        if order_sheet_name not in existing_sheets:
            template_sheet = sh.worksheet("Заказ_Ардус") if "Заказ_Ардус" in existing_sheets else sh.get_worksheet(0)
            data = template_sheet.get_all_values()
            new_ws = sh.add_worksheet(title=order_sheet_name, rows=len(data)+10, cols=10)
            if data:
                new_ws.update(data)
            print(f"✅ {order_sheet_name} varag'i yaratildi!")
        else:
            print(f"ℹ️ {order_sheet_name} varag'i allaqachon mavjud.")
            
        # 2. Alohida Tranzaksiya varag'ini yaratish
        tx_sheet_name = f"Транзакции_{b}"
        if tx_sheet_name not in existing_sheets:
            tx_template = sh.worksheet("Транзакции_Ардус") if "Транзакции_Ардус" in existing_sheets else (sh.worksheet("Транзакции") if "Транзакции" in existing_sheets else sh.get_worksheet(0))
            tx_data = tx_template.get_all_values()
            # Faqat sarlavhani qoldirib, qolgan ma'lumotlarni tozalash (yoki nusxalash)
            header_only = [tx_data[0]] if tx_data else [["Дата", "Время", "Филиал", "Тип документа", "№", "Наименование", "Штрих-код", "Количество", "Кассир", "Примечание"]]
            new_tx_ws = sh.add_worksheet(title=tx_sheet_name, rows=100, cols=10)
            new_tx_ws.update(header_only)
            print(f"✅ {tx_sheet_name} alohida tranzaksiya varag'i yaratildi!")
        else:
            print(f"ℹ️ {tx_sheet_name} varag'i allaqachon mavjud.")
            
    # 3. Остатки_Live varag'iga ustunlar qo'shish
    live_sheet_name = getattr(config, "SHEET_LIVE_STOCK", "Остатки_Live")
    if live_sheet_name in existing_sheets:
        live_ws = sh.worksheet(live_sheet_name)
        header_row = live_ws.row_values(1)
        
        for b in new_branches:
            if b not in header_row:
                header_row.append(b)
        
        live_ws.update(values=[header_row], range_name=f"A1:{chr(64 + len(header_row))}1")
        print(f"✅ Остатки_Live sahifasiga yangi filiallar ustunlari qo'shildi!")
    else:
        print(f"⚠️ {live_sheet_name} varag'i topilmadi.")

if __name__ == "__main__":
    main()
